from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from core.config import settings
from core.db import engine, Base

from addons.base.api.user_api import router as user_router
from addons.base.api.company_api import router as company_router
from addons.base.api.partner_api import router as partner_router
from addons.sales.api.sales_api import router as sales_router
from addons.purchase.api.purchase_api import router as purchase_router
from addons.inventory.api.inventory_api import router as inventory_router
from addons.crm.api.crm_api import router as crm_router
from addons.hr.api.hr_api import router as hr_router
from addons.projects.api.projects_api import router as projects_router
from addons.accounting.api.accounting_api import router as accounting_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield

app = FastAPI(
    title="Mahraj ERP",
    description="Enterprise Resource Planning System - Mahraj Technologies",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(user_router, prefix="/api/users", tags=["Users"])
app.include_router(company_router, prefix="/api/companies", tags=["Companies"])
app.include_router(partner_router, prefix="/api/partners", tags=["Partners"])
app.include_router(sales_router, prefix="/api/sales", tags=["Sales"])
app.include_router(purchase_router, prefix="/api/purchase", tags=["Purchase"])
app.include_router(inventory_router, prefix="/api/inventory", tags=["Inventory"])
app.include_router(crm_router, prefix="/api/crm", tags=["CRM"])
app.include_router(hr_router, prefix="/api/hr", tags=["HR"])
app.include_router(projects_router, prefix="/api/projects", tags=["Projects"])
app.include_router(accounting_router, prefix="/api/accounting", tags=["Accounting"])

@app.get("/")
def root():
    return {"message": "Mahraj ERP API", "version": "1.0.0", "status": "active"}

@app.get("/health")
def health_check():
    return {"status": "healthy"}
