"""Seed initial data for Mahraj ERP"""
import sys
sys.path.insert(0, '.')

from core.db import engine, SessionLocal, Base
from core.security.auth import get_password_hash
from addons.base.models.res_company import Company
from addons.base.models.res_user import User
from addons.base.models.res_partner import Partner
from addons.inventory.models.product import Product, ProductCategory, Warehouse
from addons.accounting.models.account import Account, Journal

# Import all models so tables are created
from addons.sales.models.sale_order import SaleOrder, SaleOrderLine
from addons.purchase.models.purchase_order import PurchaseOrder, PurchaseOrderLine
from addons.crm.models.crm_lead import CRMLead
from addons.hr.models.hr_employee import Employee, Department, Job
from addons.projects.models.project import Project, Task

Base.metadata.create_all(bind=engine)
db = SessionLocal()

try:
    # Company
    if not db.query(Company).first():
        company = Company(name="Mahraj Industries LLC", code="MI", email="info@mahraj.com", phone="+971-4-000-0000", city="Dubai", country="UAE", currency="AED")
        db.add(company); db.flush()
        
        # Admin user
        admin = User(name="Admin", email="admin@mahraj.com", password_hash=get_password_hash("admin123"), company_id=company.id, is_admin=True)
        db.add(admin)
        
        # Partners
        for name, type_, email in [("Al Noor Trading", "customer", "alnoor@test.com"), ("Gulf Supplies LLC", "supplier", "gulf@test.com"), ("Emirates Corp", "customer", "emirates@test.com")]:
            db.add(Partner(name=name, type=type_, email=email, country="UAE"))
        
        # Product Category
        cat = ProductCategory(name="General"); db.add(cat); db.flush()
        
        # Products
        for name, price, qty in [("Office Desk", 850, 20), ("Laptop", 4500, 15), ("A4 Paper", 25, 500), ("Office Chair", 650, 30)]:
            db.add(Product(name=name, sale_price=price, purchase_price=price*0.7, qty_on_hand=qty, category_id=cat.id, can_be_sold=True, can_be_purchased=True))
        
        # Warehouse
        db.add(Warehouse(name="Main Warehouse", code="WH", company_id=company.id))
        
        # Chart of Accounts
        for code, name, atype in [("1000", "Cash", "asset"), ("1100", "Accounts Receivable", "asset"), ("2000", "Accounts Payable", "liability"), ("3000", "Capital", "equity"), ("4000", "Sales Revenue", "income"), ("5000", "Cost of Goods Sold", "expense"), ("6000", "Operating Expenses", "expense")]:
            db.add(Account(code=code, name=name, account_type=atype))
        
        # Journals
        for name, jtype, code in [("Sales", "sale", "SAL"), ("Purchase", "purchase", "PUR"), ("Bank", "bank", "BNK"), ("Cash", "cash", "CSH"), ("Miscellaneous", "general", "MISC")]:
            db.add(Journal(name=name, type=jtype, code=code, company_id=company.id))
        
        # HR
        dept = Department(name="Operations", company_id=company.id); db.add(dept); db.flush()
        job = Job(name="Manager", department_id=dept.id); db.add(job); db.flush()
        db.add(Employee(name="Ahmed Al Rashid", work_email="ahmed@mahraj.com", department_id=dept.id, job_id=job.id))
        
        db.commit()
        print("✅ Seed data created successfully!")
    else:
        print("ℹ️  Data already exists, skipping seed.")
except Exception as e:
    db.rollback()
    print(f"❌ Error: {e}")
    raise
finally:
    db.close()
