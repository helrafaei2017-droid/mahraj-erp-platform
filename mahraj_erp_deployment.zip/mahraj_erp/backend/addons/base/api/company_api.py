from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from core.db import get_db
from core.security.auth import get_current_active_user
from addons.base.models.res_user import User
from addons.base.models.res_company import Company
from pydantic import BaseModel
from typing import Optional

router = APIRouter()

class CompanyCreate(BaseModel):
    name: str; code: str; email: Optional[str] = None; phone: Optional[str] = None; country: str = "UAE"; currency: str = "AED"

@router.get("/")
def list_companies(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return [c.to_dict() for c in db.query(Company).all()]

@router.post("/")
def create_company(data: CompanyCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    c = Company(**data.dict()); db.add(c); db.commit(); db.refresh(c)
    return c.to_dict()
