from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
from core.db import get_db
from core.security.auth import get_current_active_user
from addons.base.models.res_user import User
from addons.base.models.res_partner import Partner
from pydantic import BaseModel

router = APIRouter()

class PartnerCreate(BaseModel):
    name: str; email: Optional[str] = None; phone: Optional[str] = None; type: str = "contact"; vat: Optional[str] = None

@router.get("/")
def list_partners(type: Optional[str] = None, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    q = db.query(Partner).filter(Partner.active == True)
    if type: q = q.filter(Partner.type == type)
    return [p.to_dict() for p in q.all()]

@router.post("/")
def create_partner(data: PartnerCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    p = Partner(**data.dict()); db.add(p); db.commit(); db.refresh(p)
    return p.to_dict()

@router.get("/{partner_id}")
def get_partner(partner_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    p = db.query(Partner).filter(Partner.id == partner_id).first()
    if not p: raise HTTPException(status_code=404, detail="Partner not found")
    return p.to_dict()
