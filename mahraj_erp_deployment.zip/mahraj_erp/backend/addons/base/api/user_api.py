from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from datetime import timedelta
from core.db import get_db
from core.config import settings
from core.security.auth import verify_password, create_access_token, get_password_hash, get_current_active_user
from addons.base.models.res_user import User
from pydantic import BaseModel

router = APIRouter()

class UserLogin(BaseModel):
    email: str
    password: str

class UserCreate(BaseModel):
    name: str
    email: str
    password: str
    company_id: int = 1

@router.post("/login")
def login(user_data: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == user_data.email).first()
    if not user or not verify_password(user_data.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect email or password")
    access_token = create_access_token(data={"sub": str(user.id)}, expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    return {"access_token": access_token, "token_type": "bearer", "user": user.to_dict()}

@router.post("/register")
def register(user_data: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == user_data.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")
    user = User(name=user_data.name, email=user_data.email, password_hash=get_password_hash(user_data.password), company_id=user_data.company_id)
    db.add(user); db.commit(); db.refresh(user)
    access_token = create_access_token(data={"sub": str(user.id)})
    return {"access_token": access_token, "token_type": "bearer", "user": user.to_dict()}

@router.get("/me")
def get_me(current_user: User = Depends(get_current_active_user)):
    return current_user.to_dict()

@router.get("/")
def list_users(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return [u.to_dict() for u in db.query(User).all()]
