from sqlalchemy import Column, Integer, String, Boolean
from sqlalchemy.orm import relationship
from core.db import Base

class Company(Base):
    __tablename__ = "res_companies"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    code = Column(String(20), unique=True)
    email = Column(String(100))
    phone = Column(String(30))
    address = Column(String(500))
    city = Column(String(100))
    country = Column(String(100), default="UAE")
    currency = Column(String(10), default="AED")
    active = Column(Boolean, default=True)
    users = relationship("User", back_populates="company")
    def to_dict(self):
        return {"id": self.id, "name": self.name, "code": self.code, "email": self.email, "phone": self.phone, "city": self.city, "country": self.country, "currency": self.currency}
