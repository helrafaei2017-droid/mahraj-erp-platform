from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from core.db import Base

class User(Base):
    __tablename__ = "res_users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    company_id = Column(Integer, ForeignKey("res_companies.id"))
    active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    company = relationship("Company", back_populates="users")
    def to_dict(self):
        return {"id": self.id, "name": self.name, "email": self.email, "company_id": self.company_id, "is_admin": self.is_admin, "active": self.active}

class Group(Base):
    __tablename__ = "res_groups"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    full_name = Column(String(200))

class Permission(Base):
    __tablename__ = "res_permissions"
    id = Column(Integer, primary_key=True, index=True)
    group_id = Column(Integer, ForeignKey("res_groups.id"))
    model = Column(String(100))
    can_read = Column(Boolean, default=True)
    can_write = Column(Boolean, default=False)
    can_create = Column(Boolean, default=False)
    can_delete = Column(Boolean, default=False)
