from sqlalchemy import Column, Integer, String, Boolean, Text
from core.db import Base

class Partner(Base):
    __tablename__ = "res_partners"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    email = Column(String(100))
    phone = Column(String(30))
    mobile = Column(String(30))
    type = Column(String(20), default="contact")  # customer, supplier, contact
    company_name = Column(String(255))
    address = Column(Text)
    city = Column(String(100))
    country = Column(String(100), default="UAE")
    vat = Column(String(50))
    active = Column(Boolean, default=True)
    def to_dict(self):
        return {"id": self.id, "name": self.name, "email": self.email, "phone": self.phone, "type": self.type, "company_name": self.company_name, "city": self.city, "country": self.country, "vat": self.vat}
