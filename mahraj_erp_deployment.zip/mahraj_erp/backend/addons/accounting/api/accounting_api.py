from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
from core.db import get_db
from core.security.auth import get_current_active_user
from addons.base.models.res_user import User
from addons.accounting.models.account import Account, Journal, JournalEntry, JournalEntryLine
from pydantic import BaseModel
from typing import List

router = APIRouter()

class JournalEntryLineCreate(BaseModel):
    account_id: int; name: str; debit: float = 0; credit: float = 0

class JournalEntryCreate(BaseModel):
    journal_id: int; reference: Optional[str] = None; note: Optional[str] = None; lines: List[JournalEntryLineCreate]

@router.get("/accounts")
def list_accounts(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return [a.to_dict() for a in db.query(Account).filter(Account.active == True).all()]

@router.get("/journals")
def list_journals(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return [j.to_dict() for j in db.query(Journal).all()]

@router.get("/entries")
def list_entries(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return [e.to_dict() for e in db.query(JournalEntry).all()]

@router.post("/entries")
def create_entry(data: JournalEntryCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    last = db.query(JournalEntry).order_by(JournalEntry.id.desc()).first()
    num = f"JE{str((last.id if last else 0)+1).zfill(5)}"
    entry = JournalEntry(name=num, journal_id=data.journal_id, reference=data.reference, note=data.note)
    db.add(entry); db.flush()
    total = 0
    for l in data.lines:
        line = JournalEntryLine(entry_id=entry.id, **l.dict())
        db.add(line); total += l.debit
    entry.amount = total; db.commit(); db.refresh(entry)
    return entry.to_dict()
