from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean, Numeric, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from core.db import Base

class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(20), unique=True, nullable=False)
    name = Column(String(200), nullable=False)
    account_type = Column(String(50))  # asset, liability, income, expense, equity
    active = Column(Boolean, default=True)
    def to_dict(self):
        return {"id": self.id, "code": self.code, "name": self.name, "account_type": self.account_type}

class Journal(Base):
    __tablename__ = "account_journals"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    type = Column(String(20))  # sale, purchase, bank, cash, general
    code = Column(String(10), unique=True)
    company_id = Column(Integer, ForeignKey("res_companies.id"))
    def to_dict(self):
        return {"id": self.id, "name": self.name, "type": self.type, "code": self.code}

class JournalEntry(Base):
    __tablename__ = "account_journal_entries"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(64), unique=True)
    journal_id = Column(Integer, ForeignKey("account_journals.id"), nullable=False)
    date = Column(DateTime(timezone=True), server_default=func.now())
    state = Column(String(20), default="draft")  # draft, posted, cancelled
    amount = Column(Numeric(18,2), default=0)
    reference = Column(String(200))
    note = Column(Text)
    journal = relationship("Journal")
    lines = relationship("JournalEntryLine", back_populates="entry", cascade="all, delete-orphan")
    def to_dict(self):
        return {"id": self.id, "name": self.name, "journal": self.journal.name if self.journal else None, "date": self.date.isoformat() if self.date else None, "state": self.state, "amount": float(self.amount) if self.amount else 0}

class JournalEntryLine(Base):
    __tablename__ = "account_journal_entry_lines"
    id = Column(Integer, primary_key=True, index=True)
    entry_id = Column(Integer, ForeignKey("account_journal_entries.id"), nullable=False)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    name = Column(String(200))
    debit = Column(Numeric(18,2), default=0)
    credit = Column(Numeric(18,2), default=0)
    entry = relationship("JournalEntry", back_populates="lines")
    account = relationship("Account")
    def to_dict(self):
        return {"id": self.id, "account_code": self.account.code if self.account else None, "account_name": self.account.name if self.account else None, "debit": float(self.debit) if self.debit else 0, "credit": float(self.credit) if self.credit else 0}
