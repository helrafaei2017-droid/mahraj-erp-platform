from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from core.db import get_db
from core.security.auth import get_current_active_user
from addons.base.models.res_user import User
from addons.sales.models.sale_order import SaleOrder, SaleOrderLine, SaleOrderState
from addons.inventory.models.product import Product
from pydantic import BaseModel

router = APIRouter()

class OrderLineCreate(BaseModel):
    product_id: int; product_uom_qty: float = 1; price_unit: float

class SaleOrderCreate(BaseModel):
    partner_id: int; order_lines: List[OrderLineCreate]

@router.get("/orders")
def list_orders(state: Optional[str] = None, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    q = db.query(SaleOrder)
    if state: q = q.filter(SaleOrder.state == state)
    return [o.to_dict() for o in q.all()]

@router.post("/orders")
def create_order(data: SaleOrderCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    last = db.query(SaleOrder).order_by(SaleOrder.id.desc()).first()
    num = f"SO{str((last.id if last else 0)+1).zfill(5)}"
    order = SaleOrder(name=num, partner_id=data.partner_id, company_id=current_user.company_id, user_id=current_user.id, state=SaleOrderState.DRAFT)
    db.add(order); db.flush()
    for l in data.order_lines:
        p = db.query(Product).filter(Product.id == l.product_id).first()
        line = SaleOrderLine(order_id=order.id, product_id=l.product_id, name=p.name if p else '', product_uom_qty=l.product_uom_qty, price_unit=l.price_unit, price_subtotal=l.product_uom_qty * l.price_unit)
        db.add(line)
    db.commit(); db.refresh(order)
    return order.to_dict()

@router.get("/orders/{order_id}")
def get_order(order_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    order = db.query(SaleOrder).filter(SaleOrder.id == order_id).first()
    if not order: raise HTTPException(status_code=404, detail="Order not found")
    return order.to_dict()

@router.post("/orders/{order_id}/confirm")
def confirm_order(order_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    order = db.query(SaleOrder).filter(SaleOrder.id == order_id).first()
    if not order: raise HTTPException(status_code=404, detail="Order not found")
    order.state = SaleOrderState.CONFIRMED; db.commit()
    return order.to_dict()
