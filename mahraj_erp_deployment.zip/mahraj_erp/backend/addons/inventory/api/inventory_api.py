from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
from core.db import get_db
from core.security.auth import get_current_active_user
from addons.base.models.res_user import User
from addons.inventory.models.product import Product, ProductCategory, Warehouse
from pydantic import BaseModel

router = APIRouter()

class ProductCreate(BaseModel):
    name: str; type: str = "product"; sale_price: float = 0; purchase_price: float = 0; category_id: Optional[int] = None

@router.get("/products")
def list_products(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return [p.to_dict() for p in db.query(Product).filter(Product.active == True).all()]

@router.post("/products")
def create_product(data: ProductCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    p = Product(**data.dict()); db.add(p); db.commit(); db.refresh(p)
    return p.to_dict()

@router.get("/products/{product_id}")
def get_product(product_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    p = db.query(Product).filter(Product.id == product_id).first()
    if not p: raise HTTPException(status_code=404, detail="Product not found")
    return p.to_dict()

@router.get("/warehouses")
def list_warehouses(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return [w.to_dict() for w in db.query(Warehouse).all()]
