from sqlalchemy import Column, Integer, String, Boolean, Numeric, Text, ForeignKey
from sqlalchemy.orm import relationship
from core.db import Base

class ProductCategory(Base):
    __tablename__ = "product_categories"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    parent_id = Column(Integer, ForeignKey("product_categories.id"))
    def to_dict(self):
        return {"id": self.id, "name": self.name}

class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    internal_reference = Column(String(64))
    category_id = Column(Integer, ForeignKey("product_categories.id"))
    type = Column(String(20), default="product")  # product, service, consumable
    sale_price = Column(Numeric(18,2), default=0)
    purchase_price = Column(Numeric(18,2), default=0)
    qty_on_hand = Column(Numeric(18,3), default=0)
    description = Column(Text)
    active = Column(Boolean, default=True)
    can_be_sold = Column(Boolean, default=True)
    can_be_purchased = Column(Boolean, default=True)
    category = relationship("ProductCategory")
    def to_dict(self):
        return {"id": self.id, "name": self.name, "internal_reference": self.internal_reference, "type": self.type, "sale_price": float(self.sale_price) if self.sale_price else 0, "purchase_price": float(self.purchase_price) if self.purchase_price else 0, "qty_on_hand": float(self.qty_on_hand) if self.qty_on_hand else 0}

class Warehouse(Base):
    __tablename__ = "stock_warehouses"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    code = Column(String(10), unique=True)
    company_id = Column(Integer, ForeignKey("res_companies.id"))
    def to_dict(self):
        return {"id": self.id, "name": self.name, "code": self.code}
