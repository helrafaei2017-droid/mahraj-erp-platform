from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
from core.db import get_db
from core.security.auth import get_current_active_user
from addons.base.models.res_user import User
from addons.purchase.models.purchase_order import PurchaseOrder, PurchaseOrderLine, PurchaseOrderState
from addons.inventory.models.product import Product
from pydantic import BaseModel

router = APIRouter()

class POLineCreate(BaseModel):
    product_id: int; product_qty: float = 1; price_unit: float

class POCreate(BaseModel):
    partner_id: int; order_lines: List[POLineCreate]

@router.get("/orders")
def list_orders(state: Optional[str] = None, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    q = db.query(PurchaseOrder)
    if state: q = q.filter(PurchaseOrder.state == state)
    return [o.to_dict() for o in q.all()]

@router.post("/orders")
def create_order(data: POCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    last = db.query(PurchaseOrder).order_by(PurchaseOrder.id.desc()).first()
    num = f"PO{str((last.id if last else 0)+1).zfill(5)}"
    order = PurchaseOrder(name=num, partner_id=data.partner_id, company_id=current_user.company_id, user_id=current_user.id, state=PurchaseOrderState.DRAFT)
    db.add(order); db.flush()
    for l in data.order_lines:
        p = db.query(Product).filter(Product.id == l.product_id).first()
        line = PurchaseOrderLine(order_id=order.id, product_id=l.product_id, name=p.name if p else '', product_qty=l.product_qty, price_unit=l.price_unit, price_subtotal=l.product_qty * l.price_unit)
        db.add(line)
    db.commit(); db.refresh(order)
    return order.to_dict()

@router.post("/orders/{order_id}/confirm")
def confirm_order(order_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    order = db.query(PurchaseOrder).filter(PurchaseOrder.id == order_id).first()
    if not order: raise HTTPException(status_code=404, detail="Order not found")
    order.state = PurchaseOrderState.CONFIRMED; order.date_approve = datetime.now(); db.commit()
    return order.to_dict()
