from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Numeric, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from core.db import Base
import enum

class PurchaseOrderState(str, enum.Enum):
    DRAFT = "draft"; SENT = "sent"; CONFIRMED = "confirmed"; DONE = "done"; CANCELLED = "cancelled"

class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(64), nullable=False, unique=True)
    partner_id = Column(Integer, ForeignKey("res_partners.id"), nullable=False)
    company_id = Column(Integer, ForeignKey("res_companies.id"))
    user_id = Column(Integer, ForeignKey("res_users.id"))
    date_order = Column(DateTime(timezone=True), server_default=func.now())
    date_approve = Column(DateTime(timezone=True))
    amount_untaxed = Column(Numeric(18,2), default=0)
    amount_tax = Column(Numeric(18,2), default=0)
    amount_total = Column(Numeric(18,2), default=0)
    state = Column(String(20), default=PurchaseOrderState.DRAFT)
    partner = relationship("Partner")
    order_lines = relationship("PurchaseOrderLine", back_populates="order", cascade="all, delete-orphan")
    def to_dict(self):
        return {"id": self.id, "name": self.name, "partner_id": self.partner_id, "partner_name": self.partner.name if self.partner else None, "date_order": self.date_order.isoformat() if self.date_order else None, "amount_total": float(self.amount_total) if self.amount_total else 0, "state": self.state, "order_lines": [l.to_dict() for l in self.order_lines]}

class PurchaseOrderLine(Base):
    __tablename__ = "purchase_order_lines"
    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"))
    name = Column(String(255))
    product_qty = Column(Numeric(18,3), default=1)
    price_unit = Column(Numeric(18,2), default=0)
    price_subtotal = Column(Numeric(18,2), default=0)
    order = relationship("PurchaseOrder", back_populates="order_lines")
    product = relationship("Product")
    def to_dict(self):
        return {"id": self.id, "product_name": self.product.name if self.product else self.name, "product_qty": float(self.product_qty) if self.product_qty else 0, "price_unit": float(self.price_unit) if self.price_unit else 0, "price_subtotal": float(self.price_subtotal) if self.price_subtotal else 0}
