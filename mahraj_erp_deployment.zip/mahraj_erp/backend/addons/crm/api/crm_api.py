from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
from core.db import get_db
from core.security.auth import get_current_active_user
from addons.base.models.res_user import User
from addons.crm.models.crm_lead import CRMLead, LeadState
from pydantic import BaseModel

router = APIRouter()

class LeadCreate(BaseModel):
    name: str; partner_id: Optional[int] = None; email: Optional[str] = None; phone: Optional[str] = None; expected_revenue: float = 0

@router.get("/leads")
def list_leads(state: Optional[str] = None, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    q = db.query(CRMLead)
    if state: q = q.filter(CRMLead.state == state)
    return [l.to_dict() for l in q.all()]

@router.post("/leads")
def create_lead(data: LeadCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    lead = CRMLead(**data.dict(), user_id=current_user.id, state=LeadState.NEW)
    db.add(lead); db.commit(); db.refresh(lead)
    return lead.to_dict()

@router.get("/leads/{lead_id}")
def get_lead(lead_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    lead = db.query(CRMLead).filter(CRMLead.id == lead_id).first()
    if not lead: raise HTTPException(status_code=404, detail="Lead not found")
    return lead.to_dict()

@router.put("/leads/{lead_id}/state")
def update_lead_state(lead_id: int, state: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    lead = db.query(CRMLead).filter(CRMLead.id == lead_id).first()
    if not lead: raise HTTPException(status_code=404, detail="Lead not found")
    lead.state = state; db.commit()
    return lead.to_dict()
