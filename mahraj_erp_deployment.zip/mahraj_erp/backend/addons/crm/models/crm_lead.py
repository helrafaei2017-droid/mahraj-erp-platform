from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Numeric, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from core.db import Base
import enum

class LeadState(str, enum.Enum):
    NEW = "new"; QUALIFIED = "qualified"; PROPOSITION = "proposition"; WON = "won"; LOST = "lost"

class CRMLead(Base):
    __tablename__ = "crm_leads"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    partner_id = Column(Integer, ForeignKey("res_partners.id"))
    user_id = Column(Integer, ForeignKey("res_users.id"))
    email = Column(String(100))
    phone = Column(String(30))
    mobile = Column(String(30))
    expected_revenue = Column(Numeric(18,2), default=0)
    probability = Column(Numeric(5,2), default=0)
    state = Column(String(20), default=LeadState.NEW)
    date_open = Column(DateTime(timezone=True), server_default=func.now())
    date_closed = Column(DateTime(timezone=True))
    description = Column(Text)
    partner = relationship("Partner")
    def to_dict(self):
        return {"id": self.id, "name": self.name, "partner_name": self.partner.name if self.partner else None, "email": self.email, "phone": self.phone, "expected_revenue": float(self.expected_revenue) if self.expected_revenue else 0, "probability": float(self.probability) if self.probability else 0, "state": self.state, "date_open": self.date_open.isoformat() if self.date_open else None}
