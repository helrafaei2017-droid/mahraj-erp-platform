from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, Boolean, Date
from sqlalchemy.orm import relationship
from core.db import Base

class Department(Base):
    __tablename__ = "hr_departments"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    manager_id = Column(Integer, ForeignKey("hr_employees.id"))

class Job(Base):
    __tablename__ = "hr_jobs"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    department_id = Column(Integer, ForeignKey("hr_departments.id"))
    description = Column(Text)

class Employee(Base):
    __tablename__ = "hr_employees"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    work_email = Column(String(100))
    work_phone = Column(String(20))
    mobile_phone = Column(String(20))
    department_id = Column(Integer, ForeignKey("hr_departments.id"))
    job_id = Column(Integer, ForeignKey("hr_jobs.id"))
    gender = Column(String(10))
    birthday = Column(Date)
    identification_id = Column(String(50))
    passport_id = Column(String(50))
    address = Column(Text)
    active = Column(Boolean, default=True)
    department = relationship("Department", foreign_keys=[department_id])
    job = relationship("Job", foreign_keys=[job_id])

    def to_dict(self):
        return {"id": self.id, "name": self.name, "work_email": self.work_email,
                "work_phone": self.work_phone,
                "department_name": self.department.name if self.department else None,
                "job_title": self.job.name if self.job else None, "active": self.active}
