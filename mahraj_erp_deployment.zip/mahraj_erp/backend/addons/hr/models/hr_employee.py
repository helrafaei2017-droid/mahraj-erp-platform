from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean, Date, Text, Numeric
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from core.db import Base

class Department(Base):
    __tablename__ = "hr_departments"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False)
    company_id = Column(Integer, ForeignKey("res_companies.id"))
    def to_dict(self):
        return {"id": self.id, "name": self.name}

class Job(Base):
    __tablename__ = "hr_jobs"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False)
    department_id = Column(Integer, ForeignKey("hr_departments.id"))
    def to_dict(self):
        return {"id": self.id, "name": self.name}

class Employee(Base):
    __tablename__ = "hr_employees"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    work_email = Column(String(100))
    work_phone = Column(String(30))
    mobile_phone = Column(String(30))
    department_id = Column(Integer, ForeignKey("hr_departments.id"))
    job_id = Column(Integer, ForeignKey("hr_jobs.id"))
    gender = Column(String(10))
    birthday = Column(Date)
    identification_id = Column(String(50))
    passport_id = Column(String(50))
    address = Column(Text)
    active = Column(Boolean, default=True)
    department = relationship("Department")
    job = relationship("Job")
    def to_dict(self):
        return {"id": self.id, "name": self.name, "work_email": self.work_email, "work_phone": self.work_phone, "department": self.department.name if self.department else None, "job": self.job.name if self.job else None, "active": self.active}
