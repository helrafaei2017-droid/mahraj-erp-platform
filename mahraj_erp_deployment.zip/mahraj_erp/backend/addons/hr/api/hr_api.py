from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
from core.db import get_db
from core.security.auth import get_current_active_user
from addons.base.models.res_user import User
from addons.hr.models.hr_employee import Employee, Department, Job
from pydantic import BaseModel

router = APIRouter()

class EmployeeCreate(BaseModel):
    name: str; work_email: Optional[str] = None; work_phone: Optional[str] = None; department_id: Optional[int] = None; job_id: Optional[int] = None

@router.get("/employees")
def list_employees(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return [e.to_dict() for e in db.query(Employee).filter(Employee.active == True).all()]

@router.post("/employees")
def create_employee(data: EmployeeCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    e = Employee(**data.dict()); db.add(e); db.commit(); db.refresh(e)
    return e.to_dict()

@router.get("/departments")
def list_departments(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return [d.to_dict() for d in db.query(Department).all()]

@router.get("/jobs")
def list_jobs(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return [j.to_dict() for j in db.query(Job).all()]
