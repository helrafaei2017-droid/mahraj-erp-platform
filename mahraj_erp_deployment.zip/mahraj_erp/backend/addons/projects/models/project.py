from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean, Text, Numeric, Date
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from core.db import Base

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    partner_id = Column(Integer, ForeignKey("res_partners.id"))
    user_id = Column(Integer, ForeignKey("res_users.id"))
    date_start = Column(Date)
    date_end = Column(Date)
    state = Column(String(20), default="new")
    budget = Column(Numeric(18,2), default=0)
    description = Column(Text)
    tasks = relationship("Task", back_populates="project", cascade="all, delete-orphan")
    def to_dict(self):
        return {"id": self.id, "name": self.name, "state": self.state, "budget": float(self.budget) if self.budget else 0, "date_start": str(self.date_start) if self.date_start else None, "date_end": str(self.date_end) if self.date_end else None, "task_count": len(self.tasks)}

class Task(Base):
    __tablename__ = "project_tasks"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("res_users.id"))
    state = Column(String(20), default="todo")  # todo, in_progress, done, cancelled
    priority = Column(String(10), default="normal")
    deadline = Column(Date)
    description = Column(Text)
    project = relationship("Project", back_populates="tasks")
    def to_dict(self):
        return {"id": self.id, "name": self.name, "project_id": self.project_id, "state": self.state, "priority": self.priority, "deadline": str(self.deadline) if self.deadline else None}
