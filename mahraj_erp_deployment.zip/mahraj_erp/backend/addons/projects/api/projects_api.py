from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional
from core.db import get_db
from core.security.auth import get_current_active_user
from addons.base.models.res_user import User
from addons.projects.models.project import Project, Task
from pydantic import BaseModel

router = APIRouter()

class ProjectCreate(BaseModel):
    name: str; partner_id: Optional[int] = None; budget: float = 0; description: Optional[str] = None

class TaskCreate(BaseModel):
    name: str; project_id: int; priority: str = "normal"; description: Optional[str] = None

@router.get("/projects")
def list_projects(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    return [p.to_dict() for p in db.query(Project).all()]

@router.post("/projects")
def create_project(data: ProjectCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    p = Project(**data.dict(), user_id=current_user.id); db.add(p); db.commit(); db.refresh(p)
    return p.to_dict()

@router.get("/tasks")
def list_tasks(project_id: Optional[int] = None, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    q = db.query(Task)
    if project_id: q = q.filter(Task.project_id == project_id)
    return [t.to_dict() for t in q.all()]

@router.post("/tasks")
def create_task(data: TaskCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    t = Task(**data.dict(), user_id=current_user.id); db.add(t); db.commit(); db.refresh(t)
    return t.to_dict()
