# Mahraj ERP Platform

Enterprise Resource Planning System — Mahraj Technologies

## Features
- **Sales**: Quotations, Orders, Invoicing
- **Purchase**: RFQs, Purchase Orders, Vendor Management
- **Inventory**: Products, Warehouses, Stock
- **CRM**: Leads, Opportunities, Pipeline
- **HR**: Employees, Departments, Jobs
- **Projects**: Tasks, Timesheets, Milestones
- **Accounting**: Chart of Accounts, Journal Entries, Reports
- **Mobile App**: React Native unified app (iOS + Android)

## Tech Stack
| Layer | Technology |
|-------|-----------|
| Backend | Python 3.11 + FastAPI |
| ORM | SQLAlchemy |
| Database | PostgreSQL 15 |
| Frontend | React 18 + TypeScript + Tailwind CSS |
| Mobile | React Native |
| Auth | JWT + bcrypt |
| Container | Docker + Docker Compose |

## Quick Start (Docker)
```bash
docker-compose up -d
```
- Web App: http://localhost:3000
- API: http://localhost:8000
- API Docs: http://localhost:8000/docs

## Default Login
- Email: admin@mahraj.com
- Password: admin123

## Branding
- Primary: #0A1A3A (Royal Blue)
- Accent: #D4AF37 (Metallic Gold)

## License
Proprietary — Mahraj Technologies
