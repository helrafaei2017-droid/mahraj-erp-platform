import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text } from 'react-native';
import SalesListScreen from './modules/sales/SalesListScreen';

const Tab = createBottomTabNavigator();

const PlaceholderScreen = (title: string) => () => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f5f6fa' }}>
    <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#0A1A3A' }}>{title}</Text>
    <Text style={{ color: '#888', marginTop: 8 }}>Mahraj ERP Mobile</Text>
  </View>
);

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          tabBarActiveTintColor: '#D4AF37',
          tabBarInactiveTintColor: '#666',
          tabBarStyle: { backgroundColor: '#0A1A3A', borderTopColor: '#1a2d5a' },
          headerStyle: { backgroundColor: '#0A1A3A' },
          headerTintColor: '#D4AF37',
        }}>
        <Tab.Screen name="Sales" component={SalesListScreen} />
        <Tab.Screen name="Inventory" component={PlaceholderScreen('Inventory')} />
        <Tab.Screen name="HR" component={PlaceholderScreen('HR')} />
        <Tab.Screen name="Projects" component={PlaceholderScreen('Projects')} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
