import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import axios from 'axios';

const API_URL = 'http://localhost:8000/api';

const SalesListScreen: React.FC = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Note: replace with real token from auth
    axios.get(`${API_URL}/sales/orders`).then(r => setOrders(r.data)).catch(() => {}).finally(() => setLoading(false));
  }, []);

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#D4AF37" /></View>;

  return (
    <View style={styles.container}>
      <FlatList
        data={orders}
        keyExtractor={(item: any) => item.id.toString()}
        renderItem={({ item }: any) => (
          <TouchableOpacity style={styles.card}>
            <View style={styles.cardHeader}>
              <Text style={styles.orderNum}>{item.name}</Text>
              <View style={[styles.badge, { backgroundColor: item.state === 'confirmed' ? '#d1fae5' : '#f3f4f6' }]}>
                <Text style={{ color: item.state === 'confirmed' ? '#065f46' : '#374151', fontSize: 11 }}>{item.state}</Text>
              </View>
            </View>
            <Text style={styles.customer}>{item.partner_name || 'Unknown Customer'}</Text>
            <Text style={styles.amount}>AED {(item.amount_total || 0).toLocaleString()}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<View style={styles.center}><Text style={{ color: '#888' }}>No orders found</Text></View>}
        contentContainerStyle={{ padding: 16 }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f6fa' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  card: { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginBottom: 12, shadowColor: '#0A1A3A', shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  orderNum: { fontWeight: '700', fontSize: 16, color: '#0A1A3A' },
  badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20 },
  customer: { color: '#666', marginBottom: 4 },
  amount: { fontWeight: '600', color: '#D4AF37', fontSize: 15 },
});

export default SalesListScreen;
