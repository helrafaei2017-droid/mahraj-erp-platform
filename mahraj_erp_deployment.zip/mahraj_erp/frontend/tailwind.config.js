module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        mahraj: {
          blue: '#0A1A3A',
          gold: '#D4AF37',
          'blue-light': '#1a2d5a',
          'gold-light': '#e8c84a',
        }
      }
    }
  },
  plugins: []
}
