import React, { useEffect, useState } from 'react';
import { Plus, Search, RefreshCw } from 'lucide-react';
import apiClient from '../../services/apiClient';

interface Props {
  title: string;
  subtitle?: string;
  endpoint: string;
  columns?: string[];
}

const GenericListPage: React.FC<Props> = ({ title, subtitle, endpoint, columns }) => {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const fetchData = () => {
    setLoading(true);
    apiClient.get(endpoint).then(r => setItems(r.data)).catch(console.error).finally(() => setLoading(false));
  };

  useEffect(() => { fetchData(); }, [endpoint]);

  const displayCols = columns || (items.length > 0 ? Object.keys(items[0]).slice(0, 7) : []);
  const filtered = items.filter(item => Object.values(item).some(v => String(v).toLowerCase().includes(search.toLowerCase())));

  const statusColors: Record<string, string> = {
    draft: '#6B7280', sent: '#3B82F6', confirmed: '#10B981', done: '#8B5CF6',
    cancelled: '#EF4444', open: '#3B82F6', closed: '#10B981', new: '#3B82F6',
    won: '#10B981', lost: '#EF4444', qualified: '#F59E0B', active: '#10B981',
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: '#111827', marginBottom: 4 }}>{title}</h1>
          {subtitle && <p style={{ color: '#6B7280', fontSize: 14 }}>{subtitle}</p>}
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={fetchData} style={{ padding: '9px 16px', border: '1px solid #E5E7EB', borderRadius: 8, background: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: '#374151' }}>
            <RefreshCw size={14} /> Refresh
          </button>
          <button className="btn-gold" style={{ padding: '9px 18px', border: 'none', borderRadius: 8, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
            <Plus size={14} /> New
          </button>
        </div>
      </div>
      <div style={{ background: 'white', borderRadius: 10, padding: '10px 16px', marginBottom: 14, border: '1px solid #F1F3F5', display: 'flex', alignItems: 'center', gap: 8 }}>
        <Search size={15} color="#9CA3AF" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder={`Search ${title.toLowerCase()}...`}
          style={{ border: 'none', outline: 'none', fontSize: 14, width: '100%', color: '#374151' }} />
        {search && <span style={{ fontSize: 12, color: '#9CA3AF' }}>{filtered.length} results</span>}
      </div>
      <div style={{ background: 'white', borderRadius: 12, border: '1px solid #F1F3F5', overflow: 'hidden' }}>
        {loading ? (
          <div style={{ padding: 48, textAlign: 'center', color: '#9CA3AF', fontSize: 14 }}>Loading {title}...</div>
        ) : filtered.length === 0 ? (
          <div style={{ padding: 48, textAlign: 'center', color: '#9CA3AF', fontSize: 14 }}>No {title.toLowerCase()} found</div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead style={{ background: '#F9FAFB' }}>
                <tr>{displayCols.map(k => (
                  <th key={k} style={{ padding: '12px 18px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em', borderBottom: '1px solid #F1F3F5', whiteSpace: 'nowrap' }}>
                    {k.replace(/_/g, ' ')}
                  </th>
                ))}</tr>
              </thead>
              <tbody>
                {filtered.map((item: any) => (
                  <tr key={item.id} style={{ borderBottom: '1px solid #F9FAFB', cursor: 'pointer' }}
                    onMouseEnter={e => (e.currentTarget.style.background = '#FAFAFA')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'white')}>
                    {displayCols.map(k => (
                      <td key={k} style={{ padding: '14px 18px', fontSize: 13.5, color: '#374151' }}>
                        {k === 'state' || k === 'type' ? (
                          <span style={{ padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600, background: `${statusColors[String(item[k])] || '#6B7280'}18`, color: statusColors[String(item[k])] || '#6B7280' }}>
                            {String(item[k] ?? '-')}
                          </span>
                        ) : typeof item[k] === 'number' && k.includes('total') || k.includes('price') || k.includes('amount') || k.includes('revenue') ? (
                          <span style={{ fontWeight: 600, color: '#D4AF37' }}>AED {Number(item[k]).toLocaleString()}</span>
                        ) : String(item[k] ?? '-')}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {!loading && filtered.length > 0 && (
          <div style={{ padding: '12px 18px', borderTop: '1px solid #F1F3F5', fontSize: 12, color: '#9CA3AF', display: 'flex', justifyContent: 'space-between' }}>
            <span>Showing {filtered.length} of {items.length} records</span>
            <span style={{ color: '#D4AF37', fontWeight: 600 }}>Mahraj ERP</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default GenericListPage;
