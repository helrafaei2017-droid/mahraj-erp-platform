import React from 'react';
import { Plus, Search } from 'lucide-react';

interface Column { key: string; label: string; render?: (val: any, row: any) => React.ReactNode; }
interface ListViewProps {
  title: string; subtitle?: string; columns: Column[]; data: any[];
  loading?: boolean; onNew?: () => void; searchTerm?: string; onSearch?: (v: string) => void;
}

const ListView: React.FC<ListViewProps> = ({ title, subtitle, columns, data, loading, onNew, searchTerm, onSearch }) => (
  <div className="space-y-6 animate-fade-in">
    <div className="flex items-center justify-between">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
        {subtitle && <p className="text-gray-500 mt-1">{subtitle}</p>}
      </div>
      {onNew && (
        <button onClick={onNew} className="btn-gold px-4 py-2.5 rounded-lg flex items-center gap-2 text-sm font-semibold">
          <Plus size={18} /> New
        </button>
      )}
    </div>
    {onSearch && (
      <div className="bg-white rounded-xl p-4 border border-gray-100">
        <div className="relative">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input type="text" placeholder={`Search ${title.toLowerCase()}...`} value={searchTerm} onChange={e => onSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 focus:outline-none focus:border-yellow-400 text-sm" />
        </div>
      </div>
    )}
    <div className="bg-white rounded-xl border border-gray-100 overflow-hidden mahraj-card">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              {columns.map(c => (
                <th key={c.key} className="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{c.label}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {loading ? (
              <tr><td colSpan={columns.length} className="px-6 py-10 text-center text-gray-400">Loading...</td></tr>
            ) : data.length === 0 ? (
              <tr><td colSpan={columns.length} className="px-6 py-10 text-center text-gray-400">No records found</td></tr>
            ) : data.map((row, i) => (
              <tr key={row.id || i} className="hover:bg-gray-50 transition-colors">
                {columns.map(c => (
                  <td key={c.key} className="px-6 py-4 text-sm text-gray-700">
                    {c.render ? c.render(row[c.key], row) : row[c.key] ?? '—'}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

export default ListView;
