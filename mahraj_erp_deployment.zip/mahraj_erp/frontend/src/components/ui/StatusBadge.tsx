import React from 'react';

const colors: Record<string, string> = {
  draft: 'bg-gray-100 text-gray-600',
  sent: 'bg-blue-50 text-blue-600',
  confirmed: 'bg-green-50 text-green-600',
  done: 'bg-purple-50 text-purple-600',
  cancelled: 'bg-red-50 text-red-600',
  new: 'bg-blue-50 text-blue-600',
  qualified: 'bg-indigo-50 text-indigo-600',
  proposition: 'bg-yellow-50 text-yellow-700',
  won: 'bg-green-50 text-green-600',
  lost: 'bg-red-50 text-red-600',
  todo: 'bg-gray-100 text-gray-600',
  in_progress: 'bg-blue-50 text-blue-600',
  posted: 'bg-green-50 text-green-600',
};

const StatusBadge: React.FC<{ status: string }> = ({ status }) => (
  <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium capitalize ${colors[status] || 'bg-gray-100 text-gray-600'}`}>
    {status?.replace(/_/g, ' ')}
  </span>
);

export default StatusBadge;
