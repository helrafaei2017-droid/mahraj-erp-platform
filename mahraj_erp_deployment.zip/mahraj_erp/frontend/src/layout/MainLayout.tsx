import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { logout } from '../store/authSlice';
import {
  LayoutDashboard, ShoppingCart, Package, Users, Briefcase,
  FolderOpen, Calculator, TrendingUp, LogOut, Menu, X, Building2
} from 'lucide-react';

const navItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/sales', label: 'Sales', icon: TrendingUp },
  { path: '/purchase', label: 'Purchase', icon: ShoppingCart },
  { path: '/inventory', label: 'Inventory', icon: Package },
  { path: '/crm', label: 'CRM', icon: Users },
  { path: '/hr', label: 'HR', icon: Briefcase },
  { path: '/projects', label: 'Projects', icon: FolderOpen },
  { path: '/accounting', label: 'Accounting', icon: Calculator },
];

const MainLayout: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => { dispatch(logout()); navigate('/login'); };

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Sidebar */}
      <aside className={`mahraj-sidebar flex flex-col transition-all duration-300 ${collapsed ? 'w-16' : 'w-64'}`}>
        {/* Logo */}
        <div className="flex items-center justify-between p-4 border-b border-blue-800">
          {!collapsed && (
            <div>
              <div className="text-xl font-bold text-amber-400">MAHRAJ</div>
              <div className="text-xs text-blue-300">Enterprise ERP</div>
            </div>
          )}
          <button onClick={() => setCollapsed(!collapsed)} className="text-blue-300 hover:text-amber-400 transition-colors p-1 rounded">
            {collapsed ? <Menu size={20} /> : <X size={20} />}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4 overflow-y-auto">
          {navItems.map(({ path, label, icon: Icon }) => (
            <NavLink key={path} to={path} end={path === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 mx-2 rounded-lg transition-all mb-1 ${
                  isActive ? 'bg-amber-400 text-blue-900 font-semibold' : 'text-blue-200 hover:bg-blue-800 hover:text-amber-400'
                }`
              }>
              <Icon size={20} className="flex-shrink-0" />
              {!collapsed && <span className="text-sm">{label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* Logout */}
        <button onClick={handleLogout} className="flex items-center gap-3 px-4 py-3 mx-2 mb-4 rounded-lg text-blue-300 hover:text-red-400 hover:bg-blue-800 transition-all">
          <LogOut size={20} />
          {!collapsed && <span className="text-sm">Logout</span>}
        </button>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <header className="mahraj-topbar text-white px-6 py-4 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <Building2 size={20} className="text-amber-400" />
            <span className="font-semibold">Mahraj ERP Platform</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-blue-300">v1.0.0</span>
            <div className="w-8 h-8 rounded-full bg-amber-400 flex items-center justify-center text-blue-900 font-bold text-sm">A</div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default MainLayout;
