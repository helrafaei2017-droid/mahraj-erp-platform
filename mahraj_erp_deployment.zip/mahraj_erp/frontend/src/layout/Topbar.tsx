import React from 'react';
import { Bell, Search, LogOut, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Topbar: React.FC = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('mahraj_user') || '{}');

  const logout = () => {
    localStorage.removeItem('mahraj_token');
    localStorage.removeItem('mahraj_user');
    navigate('/login');
  };

  return (
    <header style={{ background: '#0A1A3A', height: 60, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px', borderBottom: '1px solid rgba(212,175,55,0.2)' }}>
      <div style={{ display: 'flex', alignItems: 'center', background: 'rgba(255,255,255,0.08)', borderRadius: 8, padding: '6px 14px', gap: 8, width: 300 }}>
        <Search size={16} color="rgba(255,255,255,0.5)" />
        <input placeholder="Search..." style={{ background: 'none', border: 'none', outline: 'none', color: 'white', fontSize: 14, width: '100%' }} />
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <button style={{ background: 'none', border: 'none', color: '#D4AF37', cursor: 'pointer', position: 'relative' }}>
          <Bell size={20} />
          <span style={{ position: 'absolute', top: -2, right: -2, background: '#EF4444', borderRadius: '50%', width: 8, height: 8 }} />
        </button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg,#D4AF37,#B8962E)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#0A1A3A', fontWeight: 700, fontSize: 13 }}>
            {user.name?.charAt(0) || 'M'}
          </div>
          <span style={{ color: 'white', fontSize: 13, fontWeight: 500 }}>{user.name || 'Admin'}</span>
        </div>
        <button onClick={logout} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.6)', cursor: 'pointer' }}>
          <LogOut size={18} />
        </button>
      </div>
    </header>
  );
};

export default Topbar;
