import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard, ShoppingCart, Package, Warehouse, Users,
  FolderKanban, BookOpen, TrendingUp, Settings, ChevronLeft, ChevronRight, Factory
} from 'lucide-react';

const nav = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/sales', icon: ShoppingCart, label: 'Sales' },
  { path: '/purchase', icon: Package, label: 'Purchase' },
  { path: '/inventory', icon: Warehouse, label: 'Inventory' },
  { path: '/crm', icon: TrendingUp, label: 'CRM' },
  { path: '/hr', icon: Users, label: 'HR' },
  { path: '/projects', icon: FolderKanban, label: 'Projects' },
  { path: '/accounting', icon: BookOpen, label: 'Accounting' },
  { path: '/manufacturing', icon: Factory, label: 'Manufacturing' },
];

const Sidebar: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  return (
    <aside style={{ background: '#0A1A3A', width: collapsed ? 64 : 220, transition: 'width 0.3s', minHeight: '100vh', display: 'flex', flexDirection: 'column', position: 'relative' }}>
      <div style={{ padding: '20px 16px', borderBottom: '1px solid rgba(212,175,55,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        {!collapsed && <div style={{ color: '#D4AF37', fontWeight: 800, fontSize: 18, letterSpacing: 1 }}>MAHRAJ ERP</div>}
        <button onClick={() => setCollapsed(!collapsed)} style={{ background: 'none', border: 'none', color: '#D4AF37', cursor: 'pointer', padding: 4 }}>
          {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
        </button>
      </div>
      <nav style={{ flex: 1, padding: '12px 8px' }}>
        {nav.map(({ path, icon: Icon, label }) => (
          <NavLink key={path} to={path} end={path === '/'} style={({ isActive }) => ({
            display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 8,
            marginBottom: 4, textDecoration: 'none', transition: 'all 0.2s',
            color: isActive ? '#0A1A3A' : 'rgba(255,255,255,0.7)',
            background: isActive ? '#D4AF37' : 'transparent',
            fontWeight: isActive ? 600 : 400, fontSize: 14,
          })}>
            <Icon size={18} />{!collapsed && <span>{label}</span>}
          </NavLink>
        ))}
      </nav>
      <div style={{ padding: '12px 8px' }}>
        <NavLink to="/settings" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 8, textDecoration: 'none', color: 'rgba(255,255,255,0.5)', fontSize: 14 }}>
          <Settings size={18} />{!collapsed && <span>Settings</span>}
        </NavLink>
      </div>
    </aside>
  );
};

export default Sidebar;
