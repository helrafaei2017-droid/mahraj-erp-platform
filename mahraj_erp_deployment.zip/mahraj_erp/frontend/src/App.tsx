import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './store';
import LoginPage from './modules/auth/LoginPage';
import MainLayout from './layout/MainLayout';
import Dashboard from './modules/dashboard/Dashboard';
import SalesList from './modules/sales/pages/SalesList';
import PurchaseList from './modules/purchase/pages/PurchaseList';
import ProductList from './modules/inventory/pages/ProductList';
import CRMList from './modules/crm/pages/CRMList';
import EmployeeList from './modules/hr/pages/EmployeeList';
import ProjectList from './modules/projects/pages/ProjectList';
import AccountingDashboard from './modules/accounting/pages/AccountingDashboard';

const PrivateRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const token = localStorage.getItem('mahraj_token');
  return token ? <>{children}</> : <Navigate to="/login" />;
};

function App() {
  return (
    <Provider store={store}>
      <Router>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/" element={<PrivateRoute><MainLayout /></PrivateRoute>}>
            <Route index element={<Dashboard />} />
            <Route path="sales" element={<SalesList />} />
            <Route path="purchase" element={<PurchaseList />} />
            <Route path="inventory" element={<ProductList />} />
            <Route path="crm" element={<CRMList />} />
            <Route path="hr" element={<EmployeeList />} />
            <Route path="projects" element={<ProjectList />} />
            <Route path="accounting" element={<AccountingDashboard />} />
          </Route>
        </Routes>
      </Router>
    </Provider>
  );
}

export default App;
