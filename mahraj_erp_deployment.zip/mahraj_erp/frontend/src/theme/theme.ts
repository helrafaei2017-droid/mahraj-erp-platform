export const MAHRAJ_COLORS = {
  primary: '#0A1A3A',
  accent: '#D4AF37',
  accentDark: '#B8962E',
  white: '#FFFFFF',
  gray50: '#F8F9FA',
  gray100: '#F1F3F5',
  success: '#10B981',
  warning: '#F59E0B',
  danger: '#EF4444',
  info: '#3B82F6',
};
