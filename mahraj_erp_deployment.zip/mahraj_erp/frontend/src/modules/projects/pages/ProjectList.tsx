import React, { useEffect, useState } from 'react';
import ListView from '../../../components/views/ListView';
import StatusBadge from '../../../components/ui/StatusBadge';
import apiClient from '../../../services/apiClient';

const ProjectList: React.FC = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    apiClient.get('/projects/projects').then(r => setProjects(r.data)).catch(() => setProjects([])).finally(() => setLoading(false));
  }, []);

  const filtered = projects.filter((p: any) => p.name?.toLowerCase().includes(search.toLowerCase()));

  const columns = [
    { key: 'name', label: 'Project Name' },
    { key: 'budget', label: 'Budget', render: (v: number) => `AED ${(v || 0).toLocaleString()}` },
    { key: 'date_start', label: 'Start Date' },
    { key: 'date_end', label: 'End Date' },
    { key: 'task_count', label: 'Tasks' },
    { key: 'state', label: 'Status', render: (v: string) => <StatusBadge status={v} /> },
  ];

  return <ListView title="Projects" subtitle="Manage projects and tasks" columns={columns} data={filtered} loading={loading} onNew={() => {}} searchTerm={search} onSearch={setSearch} />;
};

export default ProjectList;
