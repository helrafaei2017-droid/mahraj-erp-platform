import React from 'react';
import { TrendingUp, ShoppingCart, Package, Users, Briefcase, FolderOpen, Calculator, DollarSign } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const kpis = [
  { label: 'Total Revenue', value: 'AED 2.4M', change: '+12%', icon: DollarSign, color: '#D4AF37' },
  { label: 'Sales Orders', value: '248', change: '+8%', icon: TrendingUp, color: '#10b981' },
  { label: 'Purchase Orders', value: '96', change: '+3%', icon: ShoppingCart, color: '#3b82f6' },
  { label: 'Products', value: '1,240', change: '+5%', icon: Package, color: '#8b5cf6' },
  { label: 'CRM Leads', value: '184', change: '+22%', icon: Users, color: '#f59e0b' },
  { label: 'Employees', value: '142', change: '+2%', icon: Briefcase, color: '#ec4899' },
  { label: 'Active Projects', value: '37', change: '+6%', icon: FolderOpen, color: '#06b6d4' },
  { label: 'Journal Entries', value: '892', change: '+18%', icon: Calculator, color: '#84cc16' },
];

const revenueData = [
  { month: 'Jul', revenue: 180000 }, { month: 'Aug', revenue: 210000 },
  { month: 'Sep', revenue: 195000 }, { month: 'Oct', revenue: 240000 },
  { month: 'Nov', revenue: 280000 }, { month: 'Dec', revenue: 320000 },
];

const salesData = [
  { day: 'Mon', orders: 12 }, { day: 'Tue', orders: 18 }, { day: 'Wed', orders: 15 },
  { day: 'Thu', orders: 22 }, { day: 'Fri', orders: 28 }, { day: 'Sat', orders: 20 }, { day: 'Sun', orders: 8 },
];

const Dashboard: React.FC = () => (
  <div className="space-y-6 animate-fade-in">
    <div>
      <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
      <p className="text-gray-500 mt-1">Welcome to Mahraj ERP — Enterprise Command Center</p>
    </div>

    {/* KPI Cards */}
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {kpis.map(({ label, value, change, icon: Icon, color }) => (
        <div key={label} className="bg-white rounded-xl p-5 mahraj-card border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: `${color}20` }}>
              <Icon size={20} style={{ color }} />
            </div>
            <span className="text-xs font-medium text-green-500 bg-green-50 px-2 py-1 rounded-full">{change}</span>
          </div>
          <div className="text-2xl font-bold text-gray-900">{value}</div>
          <div className="text-xs text-gray-500 mt-1">{label}</div>
        </div>
      ))}
    </div>

    {/* Charts */}
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="bg-white rounded-xl p-6 mahraj-card border border-gray-100">
        <h3 className="font-bold text-gray-800 mb-4">Monthly Revenue (AED)</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={revenueData}>
            <XAxis dataKey="month" tick={{ fontSize: 12 }} />
            <YAxis tick={{ fontSize: 12 }} />
            <Tooltip />
            <Bar dataKey="revenue" fill="#D4AF37" radius={[4,4,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-white rounded-xl p-6 mahraj-card border border-gray-100">
        <h3 className="font-bold text-gray-800 mb-4">Weekly Sales Orders</h3>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={salesData}>
            <XAxis dataKey="day" tick={{ fontSize: 12 }} />
            <YAxis tick={{ fontSize: 12 }} />
            <Tooltip />
            <Line type="monotone" dataKey="orders" stroke="#0A1A3A" strokeWidth={2} dot={{ fill: '#D4AF37', r: 4 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  </div>
);

export default Dashboard;
