import React, { useEffect, useState } from 'react';
import { ShoppingCart, Package, Users, FolderKanban, TrendingUp } from 'lucide-react';
import apiClient from '../../services/apiClient';

const KPICard = ({ title, value, icon: Icon, color, bg }: any) => (
  <div style={{ background: 'white', borderRadius: 12, padding: 24, border: '1px solid #F1F3F5', display: 'flex', alignItems: 'center', gap: 16 }}>
    <div style={{ width: 52, height: 52, borderRadius: 12, background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Icon size={24} color={color} />
    </div>
    <div>
      <p style={{ fontSize: 13, color: '#6B7280', marginBottom: 4 }}>{title}</p>
      <p style={{ fontSize: 28, fontWeight: 800, color: '#111827' }}>{value}</p>
    </div>
  </div>
);

const DashboardPage: React.FC = () => {
  const [stats, setStats] = useState({ sales: 0, purchases: 0, employees: 0, projects: 0, leads: 0 });
  const user = JSON.parse(localStorage.getItem('mahraj_user') || '{}');

  useEffect(() => {
    Promise.allSettled([
      apiClient.get('/sales/orders'), apiClient.get('/purchase/orders'),
      apiClient.get('/hr/employees'), apiClient.get('/projects/projects'), apiClient.get('/crm/leads'),
    ]).then(([s, p, e, pr, l]) => setStats({
      sales: s.status === 'fulfilled' ? s.value.data.length : 0,
      purchases: p.status === 'fulfilled' ? p.value.data.length : 0,
      employees: e.status === 'fulfilled' ? e.value.data.length : 0,
      projects: pr.status === 'fulfilled' ? pr.value.data.length : 0,
      leads: l.status === 'fulfilled' ? l.value.data.length : 0,
    }));
  }, []);

  return (
    <div>
      <div style={{ marginBottom: 32 }}>
        <h1 style={{ fontSize: 28, fontWeight: 800, color: '#111827', marginBottom: 6 }}>Welcome, {user.name || 'Admin'}</h1>
        <p style={{ color: '#6B7280' }}>Here's what's happening across Mahraj Group today.</p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16 }}>
        <KPICard title="Sales Orders" value={stats.sales} icon={ShoppingCart} color="#D4AF37" bg="rgba(212,175,55,0.1)" />
        <KPICard title="Purchase Orders" value={stats.purchases} icon={Package} color="#3B82F6" bg="rgba(59,130,246,0.1)" />
        <KPICard title="Employees" value={stats.employees} icon={Users} color="#10B981" bg="rgba(16,185,129,0.1)" />
        <KPICard title="Projects" value={stats.projects} icon={FolderKanban} color="#8B5CF6" bg="rgba(139,92,246,0.1)" />
        <KPICard title="CRM Leads" value={stats.leads} icon={TrendingUp} color="#F59E0B" bg="rgba(245,158,11,0.1)" />
      </div>
    </div>
  );
};
export default DashboardPage;
