import React, { useEffect, useState } from 'react';
import ListView from '../../../components/views/ListView';
import StatusBadge from '../../../components/ui/StatusBadge';
import apiClient from '../../../services/apiClient';

const SalesList: React.FC = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    apiClient.get('/sales/orders').then(r => setOrders(r.data)).catch(() => setOrders([])).finally(() => setLoading(false));
  }, []);

  const filtered = orders.filter((o: any) =>
    o.name?.toLowerCase().includes(search.toLowerCase()) || o.partner_name?.toLowerCase().includes(search.toLowerCase())
  );

  const columns = [
    { key: 'name', label: 'Order #' },
    { key: 'partner_name', label: 'Customer' },
    { key: 'date_order', label: 'Date', render: (v: string) => v ? new Date(v).toLocaleDateString() : '—' },
    { key: 'amount_total', label: 'Total', render: (v: number) => `AED ${(v || 0).toLocaleString()}` },
    { key: 'state', label: 'Status', render: (v: string) => <StatusBadge status={v} /> },
  ];

  return <ListView title="Sales Orders" subtitle="Manage customer orders and quotations" columns={columns} data={filtered} loading={loading} onNew={() => {}} searchTerm={search} onSearch={setSearch} />;
};

export default SalesList;
