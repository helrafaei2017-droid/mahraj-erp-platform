import React, { useEffect, useState } from 'react';
import ListView from '../../../components/views/ListView';
import StatusBadge from '../../../components/ui/StatusBadge';
import apiClient from '../../../services/apiClient';

const CRMList: React.FC = () => {
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    apiClient.get('/crm/leads').then(r => setLeads(r.data)).catch(() => setLeads([])).finally(() => setLoading(false));
  }, []);

  const filtered = leads.filter((l: any) => l.name?.toLowerCase().includes(search.toLowerCase()) || l.email?.toLowerCase().includes(search.toLowerCase()));

  const columns = [
    { key: 'name', label: 'Lead Name' },
    { key: 'partner_name', label: 'Contact' },
    { key: 'email', label: 'Email' },
    { key: 'expected_revenue', label: 'Expected Revenue', render: (v: number) => `AED ${(v || 0).toLocaleString()}` },
    { key: 'probability', label: 'Probability', render: (v: number) => `${v || 0}%` },
    { key: 'state', label: 'Stage', render: (v: string) => <StatusBadge status={v} /> },
  ];

  return <ListView title="CRM Leads" subtitle="Manage leads and opportunities" columns={columns} data={filtered} loading={loading} onNew={() => {}} searchTerm={search} onSearch={setSearch} />;
};

export default CRMList;
