import React, { useEffect, useState } from 'react';
import ListView from '../../../components/views/ListView';
import apiClient from '../../../services/apiClient';

const EmployeeList: React.FC = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    apiClient.get('/hr/employees').then(r => setEmployees(r.data)).catch(() => setEmployees([])).finally(() => setLoading(false));
  }, []);

  const filtered = employees.filter((e: any) => e.name?.toLowerCase().includes(search.toLowerCase()) || e.work_email?.toLowerCase().includes(search.toLowerCase()));

  const columns = [
    { key: 'name', label: 'Employee Name' },
    { key: 'work_email', label: 'Email' },
    { key: 'work_phone', label: 'Phone' },
    { key: 'department', label: 'Department' },
    { key: 'job', label: 'Job Position' },
    { key: 'active', label: 'Status', render: (v: boolean) => <span className={`px-2 py-1 rounded-full text-xs font-medium ${v ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>{v ? 'Active' : 'Inactive'}</span> },
  ];

  return <ListView title="Employees" subtitle="Manage employees and HR" columns={columns} data={filtered} loading={loading} onNew={() => {}} searchTerm={search} onSearch={setSearch} />;
};

export default EmployeeList;
