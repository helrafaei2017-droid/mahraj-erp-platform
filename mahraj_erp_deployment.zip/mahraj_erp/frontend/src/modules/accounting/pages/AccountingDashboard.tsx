import React, { useEffect, useState } from 'react';
import apiClient from '../../../services/apiClient';
import StatusBadge from '../../../components/ui/StatusBadge';
import { BookOpen, Receipt, Database } from 'lucide-react';

const AccountingDashboard: React.FC = () => {
  const [accounts, setAccounts] = useState([]);
  const [journals, setJournals] = useState([]);
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      apiClient.get('/accounting/accounts').then(r => r.data).catch(() => []),
      apiClient.get('/accounting/journals').then(r => r.data).catch(() => []),
      apiClient.get('/accounting/entries').then(r => r.data).catch(() => []),
    ]).then(([a, j, e]) => { setAccounts(a); setJournals(j); setEntries(e); }).finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6 animate-fade-in">
      <div><h1 className="text-2xl font-bold text-gray-900">Accounting</h1><p className="text-gray-500 mt-1">Chart of accounts, journals and entries</p></div>

      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Accounts', value: accounts.length, icon: Database, color: '#D4AF37' },
          { label: 'Journals', value: journals.length, icon: BookOpen, color: '#0A1A3A' },
          { label: 'Journal Entries', value: entries.length, icon: Receipt, color: '#10b981' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-white rounded-xl p-6 mahraj-card border border-gray-100 text-center">
            <div className="inline-flex w-12 h-12 rounded-xl items-center justify-center mb-3" style={{ background: `${color}20` }}>
              <Icon size={24} style={{ color }} />
            </div>
            <div className="text-3xl font-bold text-gray-900">{loading ? '...' : value}</div>
            <div className="text-sm text-gray-500 mt-1">{label}</div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-gray-100 mahraj-card overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100"><h3 className="font-bold text-gray-800">Recent Journal Entries</h3></div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                {['Entry #', 'Journal', 'Date', 'Amount', 'Status'].map(h => (
                  <th key={h} className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading ? (
                <tr><td colSpan={5} className="px-6 py-8 text-center text-gray-400">Loading...</td></tr>
              ) : entries.length === 0 ? (
                <tr><td colSpan={5} className="px-6 py-8 text-center text-gray-400">No journal entries found</td></tr>
              ) : entries.map((e: any) => (
                <tr key={e.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-semibold text-gray-900">{e.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-700">{e.journal}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{e.date ? new Date(e.date).toLocaleDateString() : '—'}</td>
                  <td className="px-6 py-4 text-sm font-semibold">AED {(e.amount || 0).toLocaleString()}</td>
                  <td className="px-6 py-4"><StatusBadge status={e.state} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AccountingDashboard;
