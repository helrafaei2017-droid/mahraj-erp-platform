import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setCredentials } from '../../store/authSlice';
import apiClient from '../../services/apiClient';
import { Lock, Mail, Eye, EyeOff } from 'lucide-react';

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('admin@mahraj.com');
  const [password, setPassword] = useState('admin123');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const response = await apiClient.post('/users/login', { email, password });
      dispatch(setCredentials({ user: response.data.user, token: response.data.access_token }));
      navigate('/');
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #0A1A3A 0%, #1a2d5a 50%, #0A1A3A 100%)' }}>
      {/* Decorative circles */}
      <div className="absolute top-20 left-20 w-64 h-64 rounded-full opacity-5" style={{ background: '#D4AF37' }} />
      <div className="absolute bottom-20 right-20 w-96 h-96 rounded-full opacity-5" style={{ background: '#D4AF37' }} />

      <div className="relative z-10 w-full max-w-md px-6">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl mb-4" style={{ background: 'rgba(212,175,55,0.15)', border: '2px solid #D4AF37' }}>
            <span className="text-3xl font-black" style={{ color: '#D4AF37' }}>M</span>
          </div>
          <h1 className="text-3xl font-black text-white">MAHRAJ ERP</h1>
          <p className="text-blue-300 mt-1 text-sm">Powering Enterprise Excellence</p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="h-1" style={{ background: 'linear-gradient(90deg, #D4AF37, #e8c84a, #D4AF37)' }} />
          <div className="p-8">
            <h2 className="text-xl font-bold text-gray-800 mb-6">Sign in to your account</h2>

            {error && (
              <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                <div className="relative">
                  <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 text-sm"
                    style={{ '--tw-ring-color': '#D4AF37' } as any}
                    placeholder="Enter your email" required />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <div className="relative">
                  <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)}
                    className="w-full pl-10 pr-10 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 text-sm"
                    placeholder="Enter your password" required />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <button type="submit" disabled={loading}
                className="w-full py-3 rounded-lg font-bold text-sm transition-all disabled:opacity-60"
                style={{ background: '#D4AF37', color: '#0A1A3A' }}>
                {loading ? 'Signing in...' : 'Sign In'}
              </button>
            </form>

            <p className="text-center text-xs text-gray-400 mt-6">
              Default: admin@mahraj.com / admin123
            </p>
          </div>
        </div>

        <p className="text-center text-blue-400 text-xs mt-6">
          © 2024 Mahraj Technologies — All Rights Reserved
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
