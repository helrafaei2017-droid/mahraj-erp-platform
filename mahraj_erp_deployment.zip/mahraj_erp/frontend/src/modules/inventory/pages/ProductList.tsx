import React, { useEffect, useState } from 'react';
import ListView from '../../../components/views/ListView';
import apiClient from '../../../services/apiClient';

const ProductList: React.FC = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    apiClient.get('/inventory/products').then(r => setProducts(r.data)).catch(() => setProducts([])).finally(() => setLoading(false));
  }, []);

  const filtered = products.filter((p: any) => p.name?.toLowerCase().includes(search.toLowerCase()));

  const columns = [
    { key: 'internal_reference', label: 'Ref' },
    { key: 'name', label: 'Product Name' },
    { key: 'type', label: 'Type', render: (v: string) => <span className="capitalize">{v}</span> },
    { key: 'sale_price', label: 'Sale Price', render: (v: number) => `AED ${(v || 0).toLocaleString()}` },
    { key: 'qty_on_hand', label: 'On Hand' },
  ];

  return <ListView title="Products" subtitle="Manage products and stock" columns={columns} data={filtered} loading={loading} onNew={() => {}} searchTerm={search} onSearch={setSearch} />;
};

export default ProductList;
